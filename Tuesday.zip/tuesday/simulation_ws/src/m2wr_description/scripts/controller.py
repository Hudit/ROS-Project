import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
def clbk_laser(msg):
    print(msg.pose.pose.position.x)
    print(msg.pose.pose.position.y)
    msgss = Twist()
    msgss.linear.x = 0.2
    msgss.angular.z = 0
    pub.publish(msgss) 
def main():
    global pub

    rospy.init_node('reading_laser')    
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)    
    sub = rospy.Subscriber('/odom', Odometry, clbk_laser)   
    rospy.spin()
    
if __name__ == "__main__":
    main()